package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the CANCELTICKET database table.
 * 
 */
@Entity
@Table(name="Cancelticket")
@NamedQuery(name="Cancelticket.findAll", query="SELECT c FROM Cancelticket c")
public class Cancelticket implements Serializable {
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	private Date canceldate;

	private String cancelid;

	private int refundamount;

	private String refundstatus;

	//bi-directional many-to-one association to Reservation
	@ManyToOne
	@JoinColumn(name="TICKETNO")
	private Reservation reservation;

	public Cancelticket() {
	}

	public Date getCanceldate() {
		return this.canceldate;
	}

	public void setCanceldate(Date canceldate) {
		this.canceldate = canceldate;
	}

	public String getCancelid() {
		return this.cancelid;
	}

	public void setCancelid(String cancelid) {
		this.cancelid = cancelid;
	}

	public int getRefundamount() {
		return this.refundamount;
	}

	public void setRefundamount(int refundamount) {
		this.refundamount = refundamount;
	}

	public String getRefundstatus() {
		return this.refundstatus;
	}

	public void setRefundstatus(String refundstatus) {
		this.refundstatus = refundstatus;
	}

	public Reservation getReservation() {
		return this.reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

}