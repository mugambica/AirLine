package com.example.demo.layer5;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer4.FlightService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;



@RestController
public class FlightsController {
	@Autowired
	FlightService flightServ;
	@GetMapping(path="/getFlight/{flightNo}")
	@ResponseBody

}
