package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TICKETSTATUS database table.
 * 
 */
@Entity
@Table(name="ticketstatus")
@NamedQuery(name="Ticketstatus.findAll", query="SELECT t FROM Ticketstatus t")
public class Ticketstatus implements Serializable {
	private static final long serialVersionUID = 1L;

	private String ticketstatus;

	//bi-directional many-to-one association to Reservation
	@ManyToOne
	@JoinColumn(name="TICKETNO")
	private Reservation reservation;

	public Ticketstatus() {
	}

	public String getTicketstatus() {
		return this.ticketstatus;
	}

	public void setTicketstatus(String ticketstatus) {
		this.ticketstatus = ticketstatus;
	}

	public Reservation getReservation() {
		return this.reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

}