package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the FLIGHTSTATUS database table.
 * 
 */
@Entity
@Table(name="flightstatus")
@NamedQuery(name="Flightstatus.findAll", query="SELECT f FROM Flightstatus f")
public class Flightstatus implements Serializable {
	private static final long serialVersionUID = 1L;

	private String flightstatus;

	//bi-directional many-to-one association to Flights
	@ManyToOne
	@JoinColumn(name="FLIGHTID")
	private Flights flight;

	public Flightstatus() {
	}

	public String getFlightstatus() {
		return this.flightstatus;
	}

	public void setFlightstatus(String flightstatus) {
		this.flightstatus = flightstatus;
	}

	public Flights getFlight() {
		return this.flight;
	}

	public void setFlight(Flights flight) {
		this.flight = flight;
	}

}