package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Flights;

@Service
public interface FlightService {
	void addFlightService(Flights fRef);   //C - add/create
	Flights findFlightService(String flightNo);     //R - find/reading
	//List<Flights> findFlights();     //R - find all/reading all
	void modifyFlightService(Flights fRef); //U - modify/update
	void removeFlightService(int flightNo); //D - remove/delete
	
	
	
	/*
	 * List<Department5> findSqlDepartments(); List<Department5>
	 * findJpqlDepartments(); List<Department5> findJpql2Departments();
	 */
	
	
	 Set<Flights> findJpql3FlightsService();


}
