package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the SEATS database table.
 * 
 */
@Entity
@Table(name="seats")
@NamedQuery(name="Seats.findAll", query="SELECT s FROM Seats s")
public class Seats implements Serializable {
	private static final long serialVersionUID = 1L;

	private int age;

	private String agegroup;

	private String passengerfullname;

	private String seatno;

	//bi-directional many-to-one association to Reservation
	@ManyToOne
	@JoinColumn(name="TICKETNO")
	private Reservation reservation;

	public Seats() {
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getAgegroup() {
		return this.agegroup;
	}

	public void setAgegroup(String agegroup) {
		this.agegroup = agegroup;
	}

	public String getPassengerfullname() {
		return this.passengerfullname;
	}

	public void setPassengerfullname(String passengerfullname) {
		this.passengerfullname = passengerfullname;
	}

	public String getSeatno() {
		return this.seatno;
	}

	public void setSeatno(String seatno) {
		this.seatno = seatno;
	}

	public Reservation getReservation() {
		return this.reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

}