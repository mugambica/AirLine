package com.example.demo.layer3;

import java.util.List;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Flights;

@Repository
public class FlightsRepositoryImpl implements FlightsRepository
{
	
	
	@PersistenceContext
	 EntityManager entityManager;
	@Transactional
	public void addFlight(Flights fRef) {


		entityManager.persist(fRef);
	}

	@Transactional
	public Flights findFlight(String flightNo) {
	
		
		System.out.println("Flights repo....NO scope of bussiness logic here...");
		/*
		 * Flights flightObj = entityManager.find(Flights.class, flightNo);
		 * System.out.println(flightObj);
		 */
		return entityManager.find(Flights.class, flightNo);
		
	}

	@Transactional
	public void modifyFlight(Flights fRef) {
		// TODO Auto-generated method stub
		
		
		
	}

	@Transactional
	public void removeFlight(int flightNo) {
		// TODO Auto-generated method stub
		
	}

	@Transactional
	public Set<Flights> findJpql3Flights() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<Flights> findFlights() {
		// TODO Auto-generated method stub
		return null;
	}

}
