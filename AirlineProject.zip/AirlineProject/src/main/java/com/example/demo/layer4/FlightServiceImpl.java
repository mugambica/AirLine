package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.Flights;
import com.example.demo.layer3.FlightsRepository;

public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightsRepository flightRepo;
	@Override
	public void addFlightService(Flights fRef) {
		// TODO Auto-generated method stub

	}

	@Override
	public Flights findFlightService(String flightNo) {
		
		System.out.println("Flights repo....NO scope of bussiness logic here...");
		Flights flights=flightRepo.findFlight(flightNo);
		return flights;
	}

	@Override
	public void modifyFlightService(Flights fRef) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removeFlightService(int flightNo) {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<Flights> findJpql3FlightsService() {
		// TODO Auto-generated method stub
		return null;
	}

}
