package com.pojos.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the RESERVATION database table.
 * 
 */
@Entity
@NamedQuery(name="Reservation.findAll", query="SELECT r FROM Reservation r")
public class Reservation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String ticketno;

	@Column(name="\"CLASS\"")
	private String class_;

	@Temporal(TemporalType.DATE)
	private Date dateofdeparture;

	@Temporal(TemporalType.DATE)
	private Date dateofreturn;

	private int noofpassengers;

	private String paymentstatus;

	private int price;

	@Temporal(TemporalType.DATE)
	private Date ticketissue;

	private int totalprice;

	private String triptype;

	//bi-directional many-to-one association to Cancelticket
	@OneToMany(mappedBy="reservation", fetch=FetchType.EAGER)
	private Set<Cancelticket> canceltickets;

	//bi-directional many-to-one association to Flights
	@ManyToOne
	@JoinColumn(name="FLIGHTID")
	private Flights flight;

	//bi-directional many-to-one association to Signup
	@ManyToOne
	@JoinColumn(name="USERID")
	private Signup signup;

	//bi-directional many-to-one association to Seats
	@OneToMany(mappedBy="reservation", fetch=FetchType.EAGER)
	private Set<Seats> seats;

	//bi-directional many-to-one association to Ticketstatus
	@OneToMany(mappedBy="reservation", fetch=FetchType.EAGER)
	private Set<Ticketstatus> ticketstatuses;

	public Reservation() {
	}

	public String getTicketno() {
		return this.ticketno;
	}

	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}

	public String getClass_() {
		return this.class_;
	}

	public void setClass_(String class_) {
		this.class_ = class_;
	}

	public Date getDateofdeparture() {
		return this.dateofdeparture;
	}

	public void setDateofdeparture(Date dateofdeparture) {
		this.dateofdeparture = dateofdeparture;
	}

	public Date getDateofreturn() {
		return this.dateofreturn;
	}

	public void setDateofreturn(Date dateofreturn) {
		this.dateofreturn = dateofreturn;
	}

	public int getNoofpassengers() {
		return this.noofpassengers;
	}

	public void setNoofpassengers(int noofpassengers) {
		this.noofpassengers = noofpassengers;
	}

	public String getPaymentstatus() {
		return this.paymentstatus;
	}

	public void setPaymentstatus(String paymentstatus) {
		this.paymentstatus = paymentstatus;
	}

	public int getPrice() {
		return this.price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Date getTicketissue() {
		return this.ticketissue;
	}

	public void setTicketissue(Date ticketissue) {
		this.ticketissue = ticketissue;
	}

	public int getTotalprice() {
		return this.totalprice;
	}

	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}

	public String getTriptype() {
		return this.triptype;
	}

	public void setTriptype(String triptype) {
		this.triptype = triptype;
	}

	public Set<Cancelticket> getCanceltickets() {
		return this.canceltickets;
	}

	public void setCanceltickets(Set<Cancelticket> canceltickets) {
		this.canceltickets = canceltickets;
	}

	public Cancelticket addCancelticket(Cancelticket cancelticket) {
		getCanceltickets().add(cancelticket);
		cancelticket.setReservation(this);

		return cancelticket;
	}

	public Cancelticket removeCancelticket(Cancelticket cancelticket) {
		getCanceltickets().remove(cancelticket);
		cancelticket.setReservation(null);

		return cancelticket;
	}

	public Flights getFlight() {
		return this.flight;
	}

	public void setFlight(Flights flight) {
		this.flight = flight;
	}

	public Signup getSignup() {
		return this.signup;
	}

	public void setSignup(Signup signup) {
		this.signup = signup;
	}

	public Set<Seats> getSeats() {
		return this.seats;
	}

	public void setSeats(Set<Seats> seats) {
		this.seats = seats;
	}

	public Seats addSeat(Seats seat) {
		getSeats().add(seat);
		seat.setReservation(this);

		return seat;
	}

	public Seats removeSeat(Seats seat) {
		getSeats().remove(seat);
		seat.setReservation(null);

		return seat;
	}

	public Set<Ticketstatus> getTicketstatuses() {
		return this.ticketstatuses;
	}

	public void setTicketstatuses(Set<Ticketstatus> ticketstatuses) {
		this.ticketstatuses = ticketstatuses;
	}

	public Ticketstatus addTicketstatus(Ticketstatus ticketstatus) {
		getTicketstatuses().add(ticketstatus);
		ticketstatus.setReservation(this);

		return ticketstatus;
	}

	public Ticketstatus removeTicketstatus(Ticketstatus ticketstatus) {
		getTicketstatuses().remove(ticketstatus);
		ticketstatus.setReservation(null);

		return ticketstatus;
	}

}