package com.pojos.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the FLIGHTS database table.
 * 
 */
@Entity
@NamedQuery(name="Flights.findAll", query="SELECT f FROM Flights f")
public class Flights implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String flightid;

	private String arrivaltime;

	private String departuretime;

	private String destination;

	private int durationinhrs;

	private String flightname;

	private String source;

	private int totalseats;

	//bi-directional many-to-one association to Flightstatus
	@OneToMany(mappedBy="flight", fetch=FetchType.EAGER)
	private Set<Flightstatus> flightstatuses;

	//bi-directional many-to-one association to Reservation
	@OneToMany(mappedBy="flight", fetch=FetchType.EAGER)
	private Set<Reservation> reservations;

	public String getFlightid() {
		return this.flightid;
	}

	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}

	public String getArrivaltime() {
		return this.arrivaltime;
	}

	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}

	public String getDeparturetime() {
		return this.departuretime;
	}

	public void setDeparturetime(String departuretime) {
		this.departuretime = departuretime;
	}

	public String getDestination() {
		return this.destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getDurationinhrs() {
		return this.durationinhrs;
	}

	public void setDurationinhrs(int durationinhrs) {
		this.durationinhrs = durationinhrs;
	}

	public String getFlightname() {
		return this.flightname;
	}

	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}

	public String getSource() {
		return this.source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public int getTotalseats() {
		return this.totalseats;
	}

	public void setTotalseats(int totalseats) {
		this.totalseats = totalseats;
	}

	public Set<Flightstatus> getFlightstatuses() {
		return this.flightstatuses;
	}

	public void setFlightstatuses(Set<Flightstatus> flightstatuses) {
		this.flightstatuses = flightstatuses;
	}

	/*
	 * public Flightstatus addFlightstatus(Flightstatus flightstatus) {
	 * getFlightstatuses().add(flightstatus); flightstatus.setFlight(this);
	 * 
	 * return flightstatus; }
	 * 
	 * public Flightstatus removeFlightstatus(Flightstatus flightstatus) {
	 * getFlightstatuses().remove(flightstatus); flightstatus.setFlight(null);
	 * 
	 * return flightstatus; }
	 */

	public Set<Reservation> getReservations() {
		return this.reservations;
	}

	public void setReservations(Set<Reservation> reservations) {
		this.reservations = reservations;
	}

	/*
	 * public Reservation addReservation(Reservation reservation) {
	 * getReservations().add(reservation); reservation.setFlight(this);
	 * 
	 * return reservation; }
	 * 
	 * public Reservation removeReservation(Reservation reservation) {
	 * getReservations().remove(reservation); reservation.setFlight(null);
	 * 
	 * return reservation; }
	 */

}