package com.repo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.pojos.layer2.Flights;

@Repository
public interface FlightsRepository {
	
	void addFlight(Flights fRef);   //C - add/create
	Flights findFlight(String flightNo);     //R - find/reading
	//List<Flights> findFlights();     //R - find all/reading all
	void modifyFlight(Flights fRef); //U - modify/update
	void removeFlight(int flightNo); //D - remove/delete
	
	
	
	/*
	 * List<Department5> findSqlDepartments(); List<Department5>
	 * findJpqlDepartments(); List<Department5> findJpql2Departments();
	 */
	
	
	 Set<Flights> findJpql3Flights();

}
