package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Flights;
import com.example.demo.layer3.FlightsRepository;

@SpringBootTest
class AirlineProjectApplicationTests {

	
	@Autowired
	FlightsRepository flightsRepo;
	@Test
	void contextLoads() {
	//Set<Flights> flightSet = flightsRepo.findEmployeesByDeptno(30);
	
	Flights f=flightsRepo.findFlight("AIR101");
	System.out.println(f.getFlightid());
	System.out.println(f.getFlightname());
	System.out.println(f.getSource());
	
	System.out.println(f.getDestination());
	System.out.println(f.getTotalseats());
	System.out.println(f.getDeparturetime());
	System.out.println(f.getArrivaltime());
	System.out.println(f.getDurationinhrs());
	
	
	System.out.println("-----------------");
}
}

	
	
	
	
