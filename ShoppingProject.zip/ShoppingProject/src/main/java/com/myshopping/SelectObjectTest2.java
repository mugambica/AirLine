package com.myshopping;

import java.util.Iterator;



import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.myshopping.pojo.Department;
import com.myshopping.pojo.Employee;
 
public class SelectObjectTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		SessionFactory sessionFactory =
			    new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		//
		System.out.println("sessionFactory : "+sessionFactory);
		
		Session session = sessionFactory.getCurrentSession();
		System.out.println("session        : "+session);
		
		session.getTransaction().begin();
	
			Department deptObj=new Department(); // no object here
			
					//below function would run a select query
					//to fetch a single record for the primary key
			deptObj = session.get(Department.class,10); //98 is deptno
			System.out.println("DEPTNO : "+deptObj.getDepartmentNumber());
			System.out.println("DNAME  : "+deptObj.getDepartmentName());
			System.out.println("LOC    : "+deptObj.getDepartmentLocation());
			List<Employee> myEmps = deptObj.getEmpList();
			Iterator<Employee> empIter = myEmps.iterator();
			
			while(empIter.hasNext()) {
				Employee theEmp = empIter.next();
				System.out.println("EMPNO      : "+theEmp.getEmployeeNumber());
				System.out.println("ENAME      : "+theEmp.getEmployeeName());
				System.out.println("JOB        : "+theEmp.getEmployeeJob());	
				System.out.println("MGR        : "+theEmp.getEmployeeManager());
				System.out.println("HIREDATE   : "+theEmp.getEmployeeHiredate());
				System.out.println("SALARY     : "+theEmp.getEmployeeSalary());
				System.out.println("COMM       : "+theEmp.getEmployeeCommission());
				System.out.println("--------------------");
			}
		System.out.println("Commiting...");
		session.getTransaction().commit();
		
		System.out.println("Committed...");
		
	}

}
