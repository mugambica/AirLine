package com.myshopping.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MyFactory {

		SessionFactory sessionFactory = null;
	
		public SessionFactory getSessionFactory() {
		try
		{
			sessionFactory =
				    new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
			System.out.println("sessionFactory : "+sessionFactory);
		}
		catch(Exception e) {
			System.out.println("Some Problem DepartmentDAOImpl ctor : "+e);
		}
		
		return sessionFactory;
	}
}
