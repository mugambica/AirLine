package com.myshopping.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.myshopping.pojo.Department;

public class DepartmentDAOImpl implements DepartmentDAO
{
	SessionFactory sessionFactory = null;
	
	public DepartmentDAOImpl() {
		try
		{
			sessionFactory =
				    new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
			System.out.println("sessionFactory : "+sessionFactory);
		}
		catch(Exception e) {
			System.out.println("Some Problem DepartmentDAOImpl ctor : "+e);
		}
	}
	
	public void addDepartment(Department dRef) { //insert query
		try {
			Session session = sessionFactory.getCurrentSession();
			session.getTransaction().begin();
			session.save(dRef); //will fire the insert query
			System.out.println("Commiting...");
			session.getTransaction().commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Department findDepartment(int dno) {
		
		Department deptObj = null;
		
		try {
			Session session = sessionFactory.getCurrentSession();
			session.getTransaction().begin();
			deptObj = session.get(Department.class,dno); //98 is deptno
//			System.out.println("DEPTNO : "+deptObj.getDepartmentNumber());
//			System.out.println("DNAME  : "+deptObj.getDepartmentName());
//			System.out.println("LOC    : "+deptObj.getDepartmentLocation());
			System.out.println("Commiting...");
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return deptObj;
	}
	
	public 	List<Department> findDepartments() {
		Session session = sessionFactory.getCurrentSession();
		List<Department> deptList = new ArrayList<Department>(); //empty
		
		try {
			session.getTransaction().begin();
	//SQL would be  "select * from sys_dept"; <-- tablename
	//HQL would be  "from Department";        <-- POJO name instread of tablename
		    String queryString = "from Department"; //HQL and not SQL
		    	deptList = session.createQuery(queryString).list();
			session.getTransaction().commit();
		    //List list = session.createQuery(queryString).setReadOnly(true).list(); // use this setReadOnly to avoid dirty checking
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deptList;
	}
	
	public 	void modifyDepartment(Department dRef) {
		Session session = sessionFactory.getCurrentSession();
		try {
			session.getTransaction().begin();
			session.saveOrUpdate(dRef); //this will fire update query
			session.getTransaction().commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public 	void removeDepartment(Department dRef) {
		Session session = sessionFactory.getCurrentSession();
		try {
			session.getTransaction().begin();
			session.delete(dRef); //this will fire update query
			session.getTransaction().commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}