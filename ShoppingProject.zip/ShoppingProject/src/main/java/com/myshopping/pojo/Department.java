package com.myshopping.pojo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

//import com.myshopping.pojo.Employee;
import com.myshopping.pojo.Employee2;

@Entity
@Table(name="dept")
public class Department {
	@Id
	@Column(name="DEPTNO")
	private int departmentNumber;
	@Column(name="DNAME",length = 10)
	private String departmentName;
	@Column(name="LOC",length = 10)
	private String departmentLocation;
	
	@OneToMany(mappedBy = "dept", fetch = FetchType.EAGER, cascade = CascadeType.ALL )
	Set<Employee2> emplist = new HashSet<Employee2>();
	
	public Department() {
		super();
		System.out.println("Department is called");
	}

	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentLocation() {
		return departmentLocation;
	}

	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}

	public Set<Employee2> getEmplist() {
		return emplist;
	}

	public void setEmplist(Set<Employee2> emplist) {
		this.emplist = emplist;
	}

	@Override
	public String toString() {
		return "Department [departmentNumber=" + departmentNumber + ", departmentName=" + departmentName
				+ ", departmentLocation=" + departmentLocation + "]";
	}

	
	
	
	
}
