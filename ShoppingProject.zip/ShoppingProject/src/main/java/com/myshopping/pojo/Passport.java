package com.myshopping.pojo;

import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity(name="Passport")
public class Passport {
   @Id
   @Column(name = "PASSPNUM",length=8)
   private int passportNumber;
   @Column(name = "DOB")
   private Date dateOfBirth;
   @Column(name = "DOI")
   private Date dateOfIssue;
   @Column(name = "EXPDATE")
   private Date expiryDate;
   @Column(name = "FILENUM",length=10)
   private String FileNumber;
   

public int getPassportNumber() {
	return passportNumber;
}
public void setPassportNumber(int passportNumber) {
	this.passportNumber = passportNumber;
}   
public Date getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public Date getDateOfIssue() {
	return dateOfIssue;
}
public void setDateOfIssue(Date dateOfIssue) {
	this.dateOfIssue = dateOfIssue;
}
public Date getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(Date expiryDate) {
	this.expiryDate = expiryDate;
}
public String getFileNumber() {
	return FileNumber;
}
public void setFileNumber(String fileNumber) {
	FileNumber = fileNumber;
}
   
}
