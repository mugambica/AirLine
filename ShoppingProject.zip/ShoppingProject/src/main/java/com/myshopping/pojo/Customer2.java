package com.myshopping.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="cust")
public class Customer2 {
	@Id
	@Column(name="CUSTID")
	private int customerid;
	@Column(name="NAME",length = 45)
	private String name;
	@Column(name="CITY",length = 30)
	private String city;
	@Column(name="CREDITLIMIT")
	private double creditlimit;
	
	@ManyToOne
	@JoinColumn(name="REPID")
	private Employee2 empobj;
	
	//@OneToMany
	//@List<order> orderList =
	
	
	public int getCustomerid() {
		return customerid;
	}
	public Customer2() {
		super();
		System.out.println("customer2() contr.....");
		
		
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public double getCreditlimit() {
		return creditlimit;
	}
	public void setCreditlimit(double creditlimit) {
		this.creditlimit = creditlimit;
	}
	public Employee2 getEmpobj() {
		return empobj;
	}
	public void setEmpobj(Employee2 empobj) {
		this.empobj = empobj;
	}
	@Override
	public String toString() {
		return "Customer2 [customerid=" + customerid + ", name=" + name + ", city=" + city + ", creditlimit="
				+ creditlimit + "]";
	}
	
		
	
	
}
