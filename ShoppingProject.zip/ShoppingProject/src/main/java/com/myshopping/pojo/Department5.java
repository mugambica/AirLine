package com.myshopping.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Generated;

@Entity
@Table(name="department5")
public class Department5 {

		@Id
		@GeneratedValue
		@Column(name="DEPTNO")

		private int departmentNumber;
		@Column(name="DNAME",length=10)
		private String departmentName;
		@Column(name="LOC",length=10)
		private String departmentLocation;
		
		
		public int getDepartmentNumber() {
			return departmentNumber;
		}

		public void setDepartmentNumber(int departmentNumber) {
			this.departmentNumber = departmentNumber;
		}

		public String getDepartmentName() {
			return departmentName;
		}

		public void setDepartmentName(String departmentName) {
			this.departmentName = departmentName;
		}

		public String getDepartmentLocation() {
			return departmentLocation;
		}

		public void setDepartmentLocation(String departmentLocation) {
			this.departmentLocation = departmentLocation;
		}

		

		@Override
		public String toString() {
			return "Department [departmentNumber=" + departmentNumber + ", departmentName=" + departmentName
					+ ", departmentLocation=" + departmentLocation + "]";
		}

		
	


}
