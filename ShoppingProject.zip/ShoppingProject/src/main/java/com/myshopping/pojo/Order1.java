package com.myshopping.pojo;

public class Order1 {

}
