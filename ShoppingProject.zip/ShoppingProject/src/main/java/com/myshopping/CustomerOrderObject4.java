package com.myshopping;

import com.myshopping.dao.DepartmentDAOImpl;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.myshopping.pojo.Customer2;
import com.myshopping.pojo.Department;
import com.myshopping.pojo.Employee2;
 
public class CustomerOrderObject4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		SessionFactory sessionFactory =
			    new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		//
		System.out.println("sessionFactory : "+sessionFactory);
		
		Session session = sessionFactory.getCurrentSession();
		System.out.println("session        : "+session);
		
		session.getTransaction().begin();
		   
			Department deptObj=null ;
			DepartmentDAOImpl ddiObj =new DepartmentDAOImpl();
			
			 deptObj = ddiObj.findDepartment(30);
				
			 	System.out.println(deptObj);
			 	System.out.println(deptObj.getEmplist());
					System.out.println("---------Department--------");
					System.out.println("Dno     : "+deptObj.getDepartmentNumber());
					System.out.println("Dname   : "+deptObj.getDepartmentName());
					System.out.println("loc     : "+deptObj.getDepartmentLocation());
					System.out.println("*************************");
					
					System.out.println(deptObj.getEmplist().size());
					//System.out.println(deptObj.getEmplist().iterator());
					
					
					
					  Set<Employee2> myemps = deptObj.getEmplist(); Iterator<Employee2> empIter =
					  myemps.iterator();
					  while(empIter.hasNext()) {
					  System.out.println("OUTER WHILE"); Employee2 empObj = empIter.next();
					  //if(empObj.getDept().getDepartmentNumber()==deptObj.getDepartmentNumber()) {
					  System.out.println("Empno     : "+empObj.getEmployeeNumber());
					  System.out.println("Ename     : "+empObj.getEmployeeName());
					  System.out.println("Job       : "+empObj.getEmployeeJob());
					  System.out.println("MANAGER   : "+empObj.getEmployeeManager());
					  System.out.println("HIREDATE  : "+empObj.getEmployeeHiredate());
					  System.out.println("SALARY    : "+empObj.getEmployeeSalary());
					  System.out.println("COMMETION : "+empObj.getEmployeeCommission());
					  System.out.println("***********************");
					  
					  Set<Customer2> custList = empObj.getCustList(); 
					  Iterator<Customer2> custIter= custList.iterator(); 
					  while(custIter.hasNext()) {
					  System.out.println("		INNER WHILE"); Customer2 custObj = custIter.next();
					  if(empObj.getEmployeeNumber()==custObj.getEmpobj().getEmployeeNumber()) {
					  System.out.println("CustId         : "+custObj.getCustomerid());
					  System.out.println("Name            : "+custObj.getName());
					  System.out.println("City            : "+custObj.getCity());
					  System.out.println("CreditLimit     : "+custObj.getCreditlimit());
					  System.out.println("--------------------"); 
					  }//inner if }//inner while
					 }//if
					}//while
					 			
		System.out.println("Commiting...");
		session.getTransaction().commit();
		
		System.out.println("Committed...");
		
	}

}
