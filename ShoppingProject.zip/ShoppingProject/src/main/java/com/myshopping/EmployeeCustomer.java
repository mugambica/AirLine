package com.myshopping;

public class EmployeeCustomer {

}
